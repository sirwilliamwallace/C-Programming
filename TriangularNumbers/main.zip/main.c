#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c;

    /* Input all three sides of a triangle */
    printf("Enter three sides of triangle: \n");
    scanf("%d%d%d", &a, &b, &c);

    if((a < b + c) && (b < a + c) && (c < a + b))
    {
        printf("Triangular");
    }
    else
    {
        printf("None");
    }

    return 0;
}
